$(document).ready(function() {
    $('.this_is_button_to_sort_chtoli').click(function() {
        $(this).toggleClass('this_is_button_to_sort_chtoli_aktivnaya');
    });
});